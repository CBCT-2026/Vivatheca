Vivatheca endodontic model, 2x life size, STL in millimetres.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
See https://vivatheca.com/disclaimer
Not yet clinically reviewed.
Root canals and the drainage channel are drawn wider than real so they can be seen and printed.
The gum (soft tissue) is a separate STL; leave it off to see the bone and roots.
Licence: CC BY 4.0. Made by Vivatheca from BodyParts3D, (c) The Database Center for Life Science licensed under CC Attribution 4.0 International.
