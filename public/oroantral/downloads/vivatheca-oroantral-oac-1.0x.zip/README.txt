Vivatheca oroantral communication series: Stage 3, oroantral communication (OAC).
Right upper jaw, cut through the middle of the upper first molar. Scale 1.0x (life size), millimetres.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Full disclaimer: https://vivatheca.com/disclaimer

Parts (bone, gum, teeth) are separate STL files, so you can print them in different colours. Load them together as one object in your slicer. The sinus air space is not included; it shows as the hollow inside the bone.
Print notes: some layers are thin. The bone over the root tips in the at-risk stage is 0.5 mm, and the fistula lining is 0.6 mm. Print at 1.5x, or with a 0.2 mm nozzle, if they do not come out. Most slicers will add supports under the palate and the cut overhangs.
Sources and how the model was made: https://vivatheca.com/oroantral/

3D model made by Vivatheca from Z-Anatomy (the libre 3D atlas of anatomy, CC BY-SA 4.0), which uses BodyParts3D (The Database Center for Life Science, CC BY-SA 2.1 Japan). Changed: right maxilla, palatine and zygomatic bones and the right upper first and second molars extracted, cut, voxel-remeshed; sinus, gum, clot, flaps, fat pad and fistula added. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
