Vivatheca: impacted lower wisdom tooth, version 1.1 (5 November 2026). STL in millimetres.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Printed models are not sterile and must not be put in the mouth. Small parts are a choking hazard.
Full disclaimer: https://vivatheca.com/disclaimer

Size: about 1.7 times life size (166 mm long), so the roots and the nerve are easier to see. Scale to about 60% in your slicer for life size.
The file is not checked as a closed solid; repair it in your slicer before printing. Print the nerve in red if your printer can change colour.
Shows a lower left wisdom tooth tilted forward against the second molar, with its roots around the nerve. This is a less common, higher-risk arrangement.
Sources, what is simplified and how the model was made: https://vivatheca.com/models/impacted-wisdom-tooth

3D model by Luke Seifert for Vivatheca. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/). Credit: Seifert L. Vivatheca: Impacted lower wisdom tooth and matched normal, version 1.1. 2026. https://vivatheca.com/models/impacted-wisdom-tooth
