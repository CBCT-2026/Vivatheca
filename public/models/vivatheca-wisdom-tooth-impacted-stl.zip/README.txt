Vivatheca: impacted lower wisdom tooth (mesioangular, tooth 38). Left half of the lower jaw with the inferior alveolar nerve.
STL in millimetres at about 1.7 times life size (166 mm long), so the roots and nerve are easier to see. Scale it to about 60% in your slicer for life size. It is not checked as a closed solid, so repair it in your slicer before printing.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Full disclaimer: https://vivatheca.com/disclaimer

What the model shows, what is simplified, and its sources: https://vivatheca.com/models/impacted-wisdom-tooth

Modelled by Luke Seifert, Vivatheca. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
How to credit: Seifert L. Vivatheca: Impacted lower wisdom tooth and matched normal, version 1.3. 2026. https://vivatheca.com/models/impacted-wisdom-tooth. Licensed under CC BY-SA 4.0. Accessed [date].
