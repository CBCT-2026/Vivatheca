Vivatheca: alveolar bone graft in cleft lip and palate. Stage 3, long term (adult), canine substitution: the canine moved into the gap and reshaped.
One STL per part (bone, graft, soft-tissue, teeth), in millimetres, about 101 x 43 x 80 mm. Scale it in your slicer as you need. The parts are made from the web model, which is simplified for the screen: they are not checked as closed solids and have no print fittings (pegs or gaps), so repair them in your slicer before printing.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Full disclaimer: https://vivatheca.com/disclaimer

What the model shows, what is simplified, and its sources: https://vivatheca.com/models/alveolar-bone-graft

Made by Luke Seifert, Vivatheca, for a patient education research study. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/). If you share a changed version, share it under CC BY-SA 4.0.
How to credit: Seifert L. Vivatheca: Alveolar bone graft in cleft lip and palate, version 0.1. 2026. https://vivatheca.com/models/alveolar-bone-graft. Licensed under CC BY-SA 4.0. Accessed [date].
