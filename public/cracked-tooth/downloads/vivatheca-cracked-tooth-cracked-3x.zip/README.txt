Vivatheca cracked tooth model, 3x life size, STL in millimetres.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
See https://vivatheca.com/disclaimer
Not yet clinically reviewed.
Parts: print the tooth in a tooth colour, the filling or crown in another colour. The filling and crown are 0.24 mm smaller than the space they fit, so they can be lifted out.
The crack is drawn about 0.7 mm wide at this size so it can be seen; real cracks are much thinner.
Licence: CC BY-SA 4.0. Made by Vivatheca from Z-Anatomy (CC BY-SA 4.0), which uses BodyParts3D (DBCLS, CC BY-SA 2.1 Japan).
