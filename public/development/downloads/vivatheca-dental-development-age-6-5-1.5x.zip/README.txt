Vivatheca dental development series: right side of a child's upper and lower jaw at 6.5 years, 1.5 times life size, millimetres.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Full disclaimer: https://vivatheca.com/disclaimer

Parts: bone, adult teeth and any remaining baby teeth for each jaw as separate STL files, so you can print them in different colours (baby teeth blue, adult teeth yellow on the web model). The parts overlap; load them together as one object in your slicer. 1.5 times life size because a child's teeth are small; life-size (1.0x) files are available on request.
Tooth timings, jaw growth data and sources: https://vivatheca.com/development/

3D model made by Vivatheca from Z-Anatomy (the libre 3D atlas of anatomy, CC BY-SA 4.0), which uses BodyParts3D (The Database Center for Life Science, CC BY-SA 2.1 Japan). Changed: teeth and jaw shapes extracted, resized, moved and cut away for each age. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
