Vivatheca dental development series: age 7.5 years, 1.5 times life size, STL in millimetres.

Not yet clinically reviewed.
Educational model only. It shows typical anatomy or disease, not any real patient, and is simplified and may contain errors. Not for diagnosis, treatment planning, surgical guides or use in or on the body.
Printed models are not sterile and must not be put in the mouth. Small parts are a choking hazard.
Full disclaimer: https://vivatheca.com/disclaimer

Parts: upper and lower jaw, each as bone, adult teeth (print yellow) and baby teeth (print blue), so you can print them in different colours. The parts overlap; load them together as one object in your slicer.
Tooth timings are typical ages, not a standard for any one child. Sources and how the model was made: https://vivatheca.com/development/

3D model made by Vivatheca from Z-Anatomy (the libre 3D atlas of anatomy, CC BY-SA 4.0), which uses BodyParts3D (The Database Center for Life Science, CC BY-SA 2.1 Japan). Changed: teeth and jaw shapes extracted, resized, moved and cut away for each age. Licence: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/).
